# -*- coding: utf-8 -*-
"""
Created on Sun May  3 16:39:56 2020

@author: nuage
"""

import sys, os
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import (QMainWindow, QApplication, QWidget, QVBoxLayout, QHBoxLayout,
                             QFrame, QSplitter, QTextEdit, QTabWidget, QPlainTextEdit, QTableWidget, QHeaderView,
                             QAbstractItemView, QTableWidgetItem, QLabel, QDialog)
from PyQt5.QtGui import QIcon, QColor, QPainter, QFont, QTextFormat
from PyQt5.QtCore import Qt, QRect

from lexical_analysis import recognizedID
from syntax_analysis import get_syntax_result
from target_code_construction import get_target_code


class QCodeEditor(QPlainTextEdit):
    class NumberBar(QWidget):

        def __init__(self, editor):
            QWidget.__init__(self, editor)

            self.editor = editor
            self.editor.blockCountChanged.connect(self.updateWidth)
            self.editor.updateRequest.connect(self.updateContents)
            self.font = QFont()
            self.numberBarColor = QColor("#e8e8e8")

        def paintEvent(self, event):

            painter = QPainter(self)
            painter.fillRect(event.rect(), self.numberBarColor)

            block = self.editor.firstVisibleBlock()

            while block.isValid():
                blockNumber = block.blockNumber()
                block_top = self.editor.blockBoundingGeometry(block).translated(self.editor.contentOffset()).top()

                if blockNumber == self.editor.textCursor().blockNumber():
                    self.font.setBold(True)
                    painter.setPen(QColor("#000000"))
                else:
                    self.font.setBold(False)
                    painter.setPen(QColor("#717171"))

                paint_rect = QRect(0, int(block_top), self.width(), int(self.editor.fontMetrics().height()))
                painter.drawText(paint_rect, Qt.AlignCenter, str(blockNumber + 1))

                block = block.next()

        def getWidth(self):
            count = self.editor.blockCount()
            if 0 <= count < 99999:
                width = self.fontMetrics().width('99999')
            else:
                width = self.fontMetrics().width(str(count))
            return width

        def updateWidth(self):
            width = self.getWidth()
            self.editor.setViewportMargins(width, 0, 0, 0)

        def updateContents(self, rect, dy):
            if dy:
                self.scroll(0, dy)
            else:
                self.update(0, rect.y(), self.width(), rect.height())

            if rect.contains(self.editor.viewport().rect()):
                fontSize = self.editor.currentCharFormat().font().pointSize()
                self.font.setPointSize(fontSize)
                self.font.setStyle(QFont.StyleNormal)
                self.updateWidth()

    def __init__(self):

        super(QCodeEditor, self).__init__()

        self.setLineWrapMode(QPlainTextEdit.NoWrap)
        self.number_bar = self.NumberBar(self)
        self.currentLineNumber = None
        self.cursorPositionChanged.connect(self.highligtCurrentLine)
        self.setViewportMargins(40, 0, 0, 0)
        self.highligtCurrentLine()

    def resizeEvent(self, *e):
        cr = self.contentsRect()
        rec = QRect(cr.left(), cr.top(), self.number_bar.getWidth(), cr.height())
        self.number_bar.setGeometry(rec)

        QPlainTextEdit.resizeEvent(self, *e)

    def highligtCurrentLine(self):
        newCurrentLineNumber = self.textCursor().blockNumber()
        if newCurrentLineNumber != self.currentLineNumber:
            lineColor = QColor("#F0F8FF")
            self.currentLineNumber = newCurrentLineNumber
            hi_selection = QTextEdit.ExtraSelection()
            hi_selection.format.setBackground(lineColor)
            hi_selection.format.setProperty(QTextFormat.FullWidthSelection, True)
            hi_selection.cursor = self.textCursor()
            hi_selection.cursor.clearSelection()
            self.setExtraSelections([hi_selection])


class Ui_MainWindow(QMainWindow):
    def __init__(self, parent=None):
        super(Ui_MainWindow, self).__init__(parent)
        self.initUI()

    def initUI(self):
        # 标题
        self.setWindowTitle('11707990103')

        # 窗口尺寸
        self.resize(1200, 800)

        self.centralwidget = QtWidgets.QWidget(self)
        self.centralwidget.setObjectName("centralwidget")
        self.setCentralWidget(self.centralwidget)

        # 菜单
        self.initMenu()

        # 界面
        self.initInterface()

        # 绑定事件
        self.actionConnect()

    def initMenu(self):
        self.statusbar = QtWidgets.QStatusBar(self.centralwidget)
        self.statusbar.setObjectName("statusbar")
        self.setStatusBar(self.statusbar)
        self.menuBar = QtWidgets.QMenuBar(self.centralwidget)
        self.menuBar.setGeometry(QtCore.QRect(0, 0, 898, 26))
        self.menuBar.setObjectName("menuBar")
        self.menu_file = self.menuBar.addMenu("menu_file")
        self.menu_file.setObjectName("menu_file")
        self.menu_edit = self.menuBar.addMenu("menu_edit")
        self.menu_edit.setObjectName("menu_edit")
        self.menu_word = self.menuBar.addMenu("menu_word")
        self.menu_word.setObjectName("menu_word")
        self.menu_syntax = self.menuBar.addMenu("menu_syntax")
        self.menu_syntax.setObjectName("menu_syntax")
        self.menu_mid = self.menuBar.addMenu("menu_mid")
        self.menu_mid.setObjectName("menu_mid")
        self.menu_obj = self.menuBar.addMenu("menu_obj")
        self.menu_obj.setObjectName("menu_obj")
        self.menu_watch = self.menuBar.addMenu("menu_watch")
        self.menu_watch.setObjectName("menu_watch")
        self.menu_help = self.menuBar.addMenu("menu_help")
        self.menu_help.setObjectName("menu_help")
        self.setMenuBar(self.menuBar)
        self.toolBar = QtWidgets.QToolBar(self.centralwidget)
        self.toolBar.setObjectName("toolBar")
        self.addToolBar(QtCore.Qt.TopToolBarArea, self.toolBar)
        self.open = QtWidgets.QAction(self)
        self.open.setObjectName("open")
        self.save = QtWidgets.QAction(self)
        self.save.setObjectName("save")
        self.save_as = QtWidgets.QAction(self)
        self.save_as.setObjectName("save_as")
        self.exit = QtWidgets.QAction(self)
        self.exit.setObjectName("exit")
        self.revoke = QtWidgets.QAction(self)
        self.revoke.setObjectName("revoke")
        self.cut = QtWidgets.QAction(self)
        self.cut.setObjectName("cut")
        self.copy = QtWidgets.QAction(self)
        self.copy.setObjectName("copy")
        self.paste = QtWidgets.QAction(self)
        self.paste.setObjectName("paste")
        self.lexical_analyzer = QtWidgets.QAction(self)
        self.lexical_analyzer.setObjectName("lexical_analyzer")
        self.NFA_DFA_MFA = QtWidgets.QAction(self)
        self.NFA_DFA_MFA.setObjectName("NFA_DFA_MFA")
        self.syntax_analyzer = QtWidgets.QAction(self)
        self.syntax_analyzer.setObjectName("syntax_analyzer")
        self.LL1_analysis = QtWidgets.QAction(self)
        self.LL1_analysis.setObjectName("LL1_analysis")
        self.operator_first = QtWidgets.QAction(self)
        self.operator_first.setObjectName("operator_first")
        self.LR_analysis = QtWidgets.QAction(self)
        self.LR_analysis.setObjectName("LR_analysis")
        self.menu_mid_action = QtWidgets.QAction(self)
        self.menu_mid_action.setObjectName("menu_mid_action")
        self.menu_tar_action = QtWidgets.QAction(self)
        self.menu_tar_action.setObjectName("menu_tar_action")
        self.help = QtWidgets.QAction(self)
        self.help.setObjectName("help")
        self.about = QtWidgets.QAction(self)
        self.about.setObjectName("about")
        self.tool_bar = QtWidgets.QAction(self)
        self.tool_bar.setCheckable(True)
        self.tool_bar.setObjectName("tool_bar")
        self.status_bar = QtWidgets.QAction(self)
        self.status_bar.setCheckable(True)
        self.status_bar.setObjectName("status_bar")
        self.show_symbol_list = QtWidgets.QAction(self)
        self.show_symbol_list.setCheckable(True)
        self.show_symbol_list.setObjectName("show_symbol_list")
        self.menu_file.addAction(self.open)
        self.menu_file.addAction(self.save)
        self.menu_file.addAction(self.save_as)
        self.menu_file.addSeparator()
        self.menu_file.addAction(self.exit)
        self.menu_edit.addAction(self.revoke)
        self.menu_edit.addSeparator()
        self.menu_edit.addAction(self.cut)
        self.menu_edit.addAction(self.copy)
        self.menu_edit.addAction(self.paste)
        self.menu_word.addAction(self.lexical_analyzer)
        self.menu_word.addAction(self.NFA_DFA_MFA)
        self.menu_syntax.addAction(self.syntax_analyzer)
        self.menu_syntax.addAction(self.LL1_analysis)
        self.menu_syntax.addAction(self.operator_first)
        self.menu_syntax.addAction(self.LR_analysis)
        self.menu_mid.addAction(self.menu_mid_action)
        self.menu_obj.addAction(self.menu_tar_action)
        self.menu_watch.addAction(self.tool_bar)
        self.menu_watch.addAction(self.status_bar)
        self.menu_watch.addAction(self.show_symbol_list)
        self.menu_help.addAction(self.help)
        self.menu_help.addAction(self.about)
        self.menuBar.addAction(self.menu_file.menuAction())
        self.menuBar.addAction(self.menu_edit.menuAction())
        self.menuBar.addAction(self.menu_word.menuAction())
        self.menuBar.addAction(self.menu_syntax.menuAction())
        self.menuBar.addAction(self.menu_mid.menuAction())
        self.menuBar.addAction(self.menu_obj.menuAction())
        self.menuBar.addAction(self.menu_watch.menuAction())
        self.menuBar.addAction(self.menu_help.menuAction())
        self.toolBar.addAction(self.open)
        self.toolBar.addAction(self.save)
        self.toolBar.addSeparator()
        self.toolBar.addAction(self.cut)
        self.toolBar.addAction(self.copy)
        self.toolBar.addAction(self.paste)
        self.toolBar.addSeparator()
        self.toolBar.addAction(self.lexical_analyzer)
        self.toolBar.addAction(self.show_symbol_list)
        self.toolBar.addAction(self.syntax_analyzer)
        self.toolBar.addAction(self.about)

        self.retranslateUi()

    #        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self):
        _translate = QtCore.QCoreApplication.translate
        self.menu_file.setTitle(_translate("MainWindow", "文件(F)"))
        self.menu_edit.setTitle(_translate("MainWindow", "编辑(E)"))
        self.menu_word.setTitle(_translate("MainWindow", "词法分析(W)"))
        self.menu_syntax.setTitle(_translate("MainWindow", "语法分析(P)"))
        self.menu_mid.setTitle(_translate("MainWindow", "中间代码(M)"))
        self.menu_obj.setTitle(_translate("MainWindow", "目标代码(O)"))
        self.menu_watch.setTitle(_translate("MainWindow", "查看(V)"))
        self.menu_help.setTitle(_translate("MainWindow", "帮助(H)"))
        self.toolBar.setWindowTitle(_translate("MainWindow", "toolBar"))
        self.open.setText(_translate("MainWindow", "打开(O)"))
        self.open.setToolTip(_translate("MainWindow", "打开"))
        self.open.setIcon(QtGui.QIcon('images/dakai.png'))
        self.open.setShortcut(_translate("MainWindow", "Ctrl+O"))
        self.save.setText(_translate("MainWindow", "保存(S)"))
        self.save.setToolTip(_translate("MainWindow", "保存"))
        self.save.setIcon(QtGui.QIcon('images/baocun.png'))
        self.save.setShortcut(_translate("MainWindow", "Ctrl+S"))
        self.save_as.setText(_translate("MainWindow", "另存为(A)"))
        self.save_as.setToolTip(_translate("MainWindow", "另存为"))
        self.exit.setText(_translate("MainWindow", "退出(X)"))
        self.exit.setToolTip(_translate("MainWindow", "退出"))
        self.revoke.setText(_translate("MainWindow", "撤销(U)"))
        self.revoke.setToolTip(_translate("MainWindow", "撤销"))
        self.revoke.setShortcut(_translate("MainWindow", "Ctrl+Z"))
        self.cut.setText(_translate("MainWindow", "剪切(T)"))
        self.cut.setToolTip(_translate("MainWindow", "剪切"))
        self.cut.setIcon(QtGui.QIcon('images/jianqie.png'))
        self.cut.setShortcut(_translate("MainWindow", "Ctrl+X"))
        self.copy.setText(_translate("MainWindow", "复制(C)"))
        self.copy.setToolTip(_translate("MainWindow", "复制"))
        self.copy.setIcon(QtGui.QIcon('images/fuzhi.png'))
        self.copy.setShortcut(_translate("MainWindow", "Ctrl+C"))
        self.paste.setText(_translate("MainWindow", "粘贴(P)"))
        self.paste.setToolTip(_translate("MainWindow", "粘贴"))
        self.paste.setIcon(QtGui.QIcon('images/niantie.png'))
        self.paste.setShortcut(_translate("MainWindow", "Ctrl+V"))
        self.lexical_analyzer.setText(_translate("MainWindow", "词法分析器(A)"))
        self.lexical_analyzer.setToolTip(_translate("MainWindow", "词法分析器"))
        self.lexical_analyzer.setIcon(QtGui.QIcon('images/fenxi_w.png'))
        self.lexical_analyzer.setShortcut(_translate("MainWindow", "Ctrl+A"))
        self.NFA_DFA_MFA.setText(_translate("MainWindow", "NFA_DFA_MFA(N)"))
        self.NFA_DFA_MFA.setToolTip(_translate("MainWindow", "NFA_DFA_MFA"))
        self.NFA_DFA_MFA.setShortcut(_translate("MainWindow", "Ctrl+N"))
        self.syntax_analyzer.setText(_translate("MainWindow", "语法分析器(S)"))
        self.syntax_analyzer.setToolTip(_translate("MainWindow", "语法分析器"))
        self.syntax_analyzer.setIcon(QtGui.QIcon('images/fenxi_s.png'))
        self.syntax_analyzer.setShortcut(_translate("MainWindow", "Ctrl+Shift+S"))
        self.LL1_analysis.setText(_translate("MainWindow", "LL(1)预测分析(P)"))
        self.LL1_analysis.setToolTip(_translate("MainWindow", "LL(1)预测分析"))
        self.LL1_analysis.setShortcut(_translate("MainWindow", "Ctrl+P"))
        self.operator_first.setText(_translate("MainWindow", "运算符优先(O)"))
        self.operator_first.setToolTip(_translate("MainWindow", "运算符优先"))
        self.operator_first.setShortcut(_translate("MainWindow", "Ctrl+Shift+O"))
        self.LR_analysis.setText(_translate("MainWindow", "LR分析(L)"))
        self.LR_analysis.setToolTip(_translate("MainWindow", "LR分析"))
        self.LR_analysis.setShortcut(_translate("MainWindow", "Ctrl+L"))
        self.menu_mid_action.setText(_translate("MainWindow", "中间代码生成"))
        self.menu_mid_action.setToolTip(_translate("MainWindow", "生成中间代码"))
        self.menu_mid_action.setShortcut(_translate("MainWindow", "Ctrl+M"))
        self.menu_tar_action.setText(_translate("MainWindow", "目标代码生成"))
        self.menu_tar_action.setToolTip(_translate("MainWindow", "生成目标代码"))
        self.menu_tar_action.setShortcut(_translate("MainWindow", "Ctrl+T"))
        self.help.setText(_translate("MainWindow", "帮助文档"))
        self.about.setText(_translate("MainWindow", "关于(A)"))
        self.about.setToolTip(_translate("MainWindow", "关于"))
        self.about.setIcon(QtGui.QIcon('images/guanyu.png'))
        self.tool_bar.setText(_translate("MainWindow", "工具栏(T)"))
        self.tool_bar.setToolTip(_translate("MainWindow", "工具栏"))
        self.status_bar.setText(_translate("MainWindow", "状态栏(S)"))
        self.status_bar.setToolTip(_translate("MainWindow", "状态栏"))
        self.show_symbol_list.setText(_translate("MainWindow", "显示符号表信息"))
        self.show_symbol_list.setToolTip(_translate("MainWindow", "显示/隐藏符号表"))
        self.show_symbol_list.setIcon(QtGui.QIcon('images/zhuanhuan.png'))

    def initInterface(self):
        self.hbox = QHBoxLayout(self.centralwidget)

        self.edit_input = QCodeEditor()

        self.edit_mess = QTabWidget()
        self.initMess()
        self.edit_result = QTabWidget()
        self.initResult()

        self.edit_output = QSplitter(Qt.Vertical)
        self.edit_output.addWidget(self.edit_mess)
        self.edit_output.addWidget(self.edit_result)

        self.interface = QSplitter(Qt.Horizontal)
        self.interface.addWidget(self.edit_input)
        self.interface.addWidget(self.edit_output)

        self.hbox.addWidget(self.interface)

    def initMess(self):
        self.lexical_result = QWidget()
        self.lexicalResultUI()
        self.syntax_result = QWidget()
        self.syntaxResultUI()
        self.intermediate_code_list = QWidget()
        self.intermediateCodeListUI()
        self.target_code_text = QWidget()
        self.targetCodeUI()

        # 将选项卡添加到顶层窗口中
        self.edit_mess.addTab(self.lexical_result, "lexical result")
        self.edit_mess.addTab(self.syntax_result, "syntax result")
        self.edit_mess.addTab(self.intermediate_code_list, "intermediate code")
        self.edit_mess.addTab(self.target_code_text, "target code")

        self.edit_mess.setTabPosition(QtWidgets.QTabWidget.South)

    def initResult(self):
        self.result_compiler = QWidget()
        self.resultCompilertUI()
        self.constant_list = QWidget()
        self.constantListUI()
        self.variable_list = QWidget()
        self.variableListUI()
        self.function_list = QWidget()
        self.functionListUI()

        # 将选项卡添加到顶层窗口中
        self.edit_result.addTab(self.result_compiler, "compiler")
        self.edit_result.addTab(self.constant_list, "constant list")
        self.edit_result.addTab(self.variable_list, "variable list")
        self.edit_result.addTab(self.function_list, "function list")

        self.edit_result.setTabPosition(QtWidgets.QTabWidget.South)

    def lexicalResultUI(self):
        # 词法分析
        layout = QHBoxLayout()
        self.lexical_result_table = QTableWidget(1, 4)
        self.lexical_result_table.setHorizontalHeaderLabels(['行', '列', '值', 'token'])
        self.lexical_result_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)  # 自适应伸缩
        self.lexical_result_table.setEditTriggers(QAbstractItemView.NoEditTriggers)  # 禁止编辑
        QTableWidget.resizeRowsToContents(self.lexical_result_table)  # 匹配宽度
        layout.addWidget(self.lexical_result_table)
        self.lexical_result.setLayout(layout)

    def syntaxResultUI(self):
        # 语法分析
        layout = QHBoxLayout()
        self.syntax_result_val = QTextEdit()
        self.syntax_result_val.setReadOnly(True)
        layout.addWidget(self.syntax_result_val)
        self.syntax_result.setLayout(layout)

    def intermediateCodeListUI(self):
        # 中间代码
        layout = QHBoxLayout()
        self.intermediate_code_list_result = QTableWidget(1, 4)
        self.intermediate_code_list_result.setHorizontalHeaderLabels(['OP', 'ARG1', 'ARG2', 'RESULT'])
        self.intermediate_code_list_result.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)  # 自适应伸缩
        self.intermediate_code_list_result.setEditTriggers(QAbstractItemView.NoEditTriggers)  # 禁止编辑
        QTableWidget.resizeRowsToContents(self.intermediate_code_list_result)  # 匹配宽度
        layout.addWidget(self.intermediate_code_list_result)
        self.intermediate_code_list.setLayout(layout)

    def targetCodeUI(self):
        # 目标代码
        layout = QHBoxLayout()
        self.target_code_val = QTextEdit()
        self.target_code_val.setReadOnly(True)
        layout.addWidget(self.target_code_val)
        self.target_code_text.setLayout(layout)

    def resultCompilertUI(self):
        layout = QHBoxLayout()
        self.result_compiler_val = QTextEdit()
        self.result_compiler_val.setReadOnly(True)
        layout.addWidget(self.result_compiler_val)
        self.result_compiler.setLayout(layout)

    def constantListUI(self):
        # 常量表
        layout = QHBoxLayout()
        self.constant_list_result = QTableWidget(1, 4)
        self.constant_list_result.setHorizontalHeaderLabels(['名', '类型', '长度', '值'])
        self.constant_list_result.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)  # 自适应伸缩
        self.constant_list_result.setEditTriggers(QAbstractItemView.NoEditTriggers)  # 禁止编辑
        QTableWidget.resizeRowsToContents(self.constant_list_result)  # 匹配宽度
        layout.addWidget(self.constant_list_result)
        self.constant_list.setLayout(layout)

    def variableListUI(self):
        # 变量表
        layout = QHBoxLayout()
        self.variable_list_result = QTableWidget(1, 5)
        self.variable_list_result.setHorizontalHeaderLabels(['名', '作用域', '类型', '长度', '值'])
        self.variable_list_result.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)  # 自适应伸缩
        self.variable_list_result.setEditTriggers(QAbstractItemView.NoEditTriggers)  # 禁止编辑
        QTableWidget.resizeRowsToContents(self.variable_list_result)  # 匹配宽度
        layout.addWidget(self.variable_list_result)
        self.variable_list.setLayout(layout)

    def functionListUI(self):
        # 函数表
        layout = QHBoxLayout()
        self.function_list_result = QTableWidget(1, 5)
        self.function_list_result.setHorizontalHeaderLabels(['名', '作用域', '返回值类型', '参数数量', '参数类型'])
        self.function_list_result.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)  # 自适应伸缩
        self.function_list_result.setEditTriggers(QAbstractItemView.NoEditTriggers)  # 禁止编辑
        QTableWidget.resizeRowsToContents(self.function_list_result)  # 匹配宽度
        layout.addWidget(self.function_list_result)
        self.function_list.setLayout(layout)

    def actionConnect(self):
        # 绑定事件
        #        self.open.triggered.connect()
        #        self.save.triggered.connect()
        #        self.save_as.triggered.connect()
        #        self.exit.triggered.connect()
        #        self.revoke.triggered.connect()
        #        self.cut.triggered.connect()
        #        self.copy.triggered.connect()
        #        self.paste.triggered.connect()
        self.lexical_analyzer.triggered.connect(self.get_lexical_analysis_result)
        #        self.NFA_DFA_MFA.triggered.connect()
        self.syntax_analyzer.triggered.connect(self.get_syntax_analyzer_result)
        #        self.LL1_analysis.triggered.connect()
        #        self.operator_first.triggered.connect()
        #        self.LR_analysis.triggered.connect()
        self.menu_mid_action.triggered.connect(self.get_syntax_analyzer_result)
        self.menu_tar_action.triggered.connect(self.get_target_code_result)
        self.help.triggered.connect(self.get_help)
        self.about.triggered.connect(self.get_about)

    #        self.tool_bar.triggered.connect()
    #        self.status_bar.triggered.connect()
    #        self.show_symbol_list.triggered.connect()

    def maybe_save(self):
        if self.text.document().isModified():
            ret = self.tip()
            if 0 == ret:
                return self.save()
            if 2 == ret:
                return False
        return True

    #    def open_file_enent(self):
    #        # 如果先前被打开的文件已被修改，需要提示
    #        if self.maybe_save():
    #            fileName, _ = QtWidgets.QFileDialog.getOpenFileName(self)
    #            file = QtCore.QFile(fileName)
    #            if not file.open(QtCore.QFile.ReadOnly | QtCore.QFile.Text):
    #                QtWidgets.QMessageBox.warning(self, "记事本","文件%s不能被读取:\n%s." % (fileName, file.errorString()))
    #                return
    #            inf = QtCore.QTextStream(file)
    #            QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
    #            self.text.setPlainText(inf.readAll())
    #            QtWidgets.QApplication.restoreOverrideCursor()
    #
    #            self.setCurrentFile(fileName)
    #            self.statusBar().showMessage("文件读取成功", 2000)
    #
    #    def close_event(self, event):
    #        if not self.maybe_save():
    #            event.ignore()
    #        else:
    #            if not self.reset:
    #                self.writeSettings()
    #            event.accept()

    def get_lexical_analysis_result(self):
        code = self.edit_input.toPlainText()
        token_information, error_information = recognizedID(code)
        for rowNum in range(0, self.lexical_result_table.rowCount())[::-1]:  # 逆序删除，正序删除会有一些删除不成功
            self.lexical_result_table.removeRow(rowNum)
        self.result_compiler_val.clear()
        for i, line in enumerate(token_information):
            self.lexical_result_table.insertRow(i)  # 增加行
            self.lexical_result_table.setItem(i, 0, QTableWidgetItem(str(line[0])))  # 添加内容
            self.lexical_result_table.setItem(i, 1, QTableWidgetItem(str(line[1])))
            self.lexical_result_table.setItem(i, 2, QTableWidgetItem(line[3]))
            self.lexical_result_table.setItem(i, 3, QTableWidgetItem(str(line[4])))
        self.result_compiler_val.insertPlainText('词法分析结束|')  # 插入内容
        if len(error_information) > 0:
            self.result_compiler_val.insertPlainText(str(len(error_information)) + ' error(s)\n')
            for i, line in enumerate(error_information):
                self.result_compiler_val.insertPlainText(
                    str(line[0]) + ' row,' + str(line[1]) + ' column: ' + line[3] + ',' + line[4] + '\n')
        else:
            self.result_compiler_val.insertPlainText('0 error(s)\n')

        return token_information, error_information

    def get_syntax_analyzer_result(self):
        token_information, error_information = self.get_lexical_analysis_result()
        error_list, semantic_error_list, quaternion_list, symbol_constant_list, symbol_variable_list, symbol_function_list, function_param_list, syntax_tree = get_syntax_result(
            token_information)
        self.syntax_result_val.clear()
        for line in syntax_tree:
            self.syntax_result_val.insertPlainText(line + '\n')
        for rowNum in range(0, self.constant_list_result.rowCount())[::-1]:  # 逆序删除，正序删除会有一些删除不成功
            self.constant_list_result.removeRow(rowNum)
        for rowNum in range(0, self.variable_list_result.rowCount())[::-1]:  # 逆序删除，正序删除会有一些删除不成功
            self.variable_list_result.removeRow(rowNum)
        for rowNum in range(0, self.function_list_result.rowCount())[::-1]:  # 逆序删除，正序删除会有一些删除不成功
            self.function_list_result.removeRow(rowNum)
        for i, name in enumerate(symbol_constant_list.keys()):
            self.constant_list_result.insertRow(i)  # 增加行
            self.constant_list_result.setItem(i, 0, QTableWidgetItem(name))  # 添加内容
            self.constant_list_result.setItem(i, 1, QTableWidgetItem(symbol_constant_list[name][1]))
            self.constant_list_result.setItem(i, 2, QTableWidgetItem(str(symbol_constant_list[name][0])))
            self.constant_list_result.setItem(i, 3, QTableWidgetItem(symbol_constant_list[name][2]))
        i = 0
        for name in symbol_variable_list.keys():
            for key, line in symbol_variable_list[name].items():
                self.variable_list_result.insertRow(i)  # 增加行
                self.variable_list_result.setItem(i, 0, QTableWidgetItem(name))  # 添加内容
                self.variable_list_result.setItem(i, 1, QTableWidgetItem(key))
                self.variable_list_result.setItem(i, 2, QTableWidgetItem(line[2]))
                self.variable_list_result.setItem(i, 3, QTableWidgetItem(str(line[1])))
                self.variable_list_result.setItem(i, 4, QTableWidgetItem(str(line[3])))
                i += 1
        i = 0
        for name in symbol_function_list.keys():
            for key, line in symbol_function_list[name].items():
                self.function_list_result.insertRow(i)  # 增加行
                self.function_list_result.setItem(i, 0, QTableWidgetItem(name))  # 添加内容
                self.function_list_result.setItem(i, 1, QTableWidgetItem(key))
                self.function_list_result.setItem(i, 2, QTableWidgetItem(line[1]))
                self.function_list_result.setItem(i, 3, QTableWidgetItem(str(line[2])))
                if len(line) < 3:
                    self.function_list_result.setItem(i, 4, QTableWidgetItem(''))
                else:
                    add_p = ''
                    for param in line[3:]:
                        add_p += param + ','
                    self.function_list_result.setItem(i, 4, QTableWidgetItem(add_p[:-1]))
                i += 1

        for rowNum in range(0, self.intermediate_code_list_result.rowCount())[::-1]:  # 逆序删除，正序删除会有一些删除不成功
            self.intermediate_code_list_result.removeRow(rowNum)
        #        quaternion_list=quaternion_list[1:]
        for i, line in enumerate(quaternion_list[1:]):
            self.intermediate_code_list_result.insertRow(i)  # 增加行
            self.intermediate_code_list_result.setItem(i, 0, QTableWidgetItem(str(line[0])))  # 添加内容
            self.intermediate_code_list_result.setItem(i, 1, QTableWidgetItem(str(line[1])))
            self.intermediate_code_list_result.setItem(i, 2, QTableWidgetItem(str(line[2])))
            self.intermediate_code_list_result.setItem(i, 3, QTableWidgetItem(str(line[3])))

        self.result_compiler_val.insertPlainText('语法分析结束|')  # 插入内容
        if len(error_list) > 0:
            self.result_compiler_val.insertPlainText(str(len(error_list)) + ' error(s)\n')
            for i, line in enumerate(error_list):
                self.result_compiler_val.insertPlainText(
                    str(line[0]) + ' row,' + str(line[1]) + ' column: ' + line[2] + '\n')
        else:
            self.result_compiler_val.insertPlainText('0 error(s)\n')

        self.result_compiler_val.insertPlainText('语义分析结束|')  # 插入内容
        if len(semantic_error_list) > 0:
            self.result_compiler_val.insertPlainText(str(len(semantic_error_list)) + ' error(s)\n')
            for i, line in enumerate(semantic_error_list):
                self.result_compiler_val.insertPlainText(
                    str(line[0]) + ' row,' + str(line[1]) + ' column: ' + line[2] + '\n')
        else:
            self.result_compiler_val.insertPlainText('0 error(s)\n')

        return quaternion_list, symbol_constant_list, symbol_variable_list, symbol_function_list, function_param_list

    def get_target_code_result(self):
        quaternion_list, symbol_constant_list, symbol_variable_list, symbol_function_list, function_param_list = self.get_syntax_analyzer_result()
        target_code_list = get_target_code(
            [quaternion_list, symbol_constant_list, symbol_variable_list, symbol_function_list, function_param_list])
        self.target_code_val.clear()
        self.target_code_val.insertPlainText(target_code_list)

    def get_help(self):
        os.startfile(os.getcwd() + "/help.chm")

    def get_about(self):
        vbox = QVBoxLayout()  # 纵向布局
        tool = QLabel()
        tool.setText("开发工具：Spyder")
        envir = QLabel()
        envir.setText("开发环境：python 3.6")
        author = QLabel()
        author.setText("作者：CQUT 11707990103 11703990438")
        func = QLabel()
        func.setText("实现功能：词法分析，语法分析，中间代码，目标代码")

        self.dialog = QDialog()
        self.dialog.resize(100, 100)

        self.dialog.setWindowTitle("关于编译程序")

        # 消息label与按钮组合纵向布局
        vbox.addWidget(tool)
        vbox.addWidget(envir)
        vbox.addWidget(author)
        vbox.addWidget(func)
        self.dialog.setLayout(vbox)

        self.dialog.setWindowModality(Qt.ApplicationModal)  # 该模式下，只有该dialog关闭，才可以关闭父界面
        self.dialog.exec_()


if __name__ == '__main__':
    if not QtWidgets.QApplication.instance():
        app = QtWidgets.QApplication(sys.argv)
    else:
        app = QtWidgets.QApplication.instance()

    app.setWindowIcon(QIcon('./images/main.png'))
    main = Ui_MainWindow()
    main.show()

    sys.exit(app.exec_())